(function($) {

    'use strict';

    var $window = $(window);
// WOW Init
    var wow = new WOW({
        boxClass: 'wow', // default
        animateClass: 'animated', // default
        offset: 0, // default
        mobile: false, // default
        live: true // default
    })
    wow.init();

   // 05. FullScreenHeight function
    function fullScreenHeight() {
        var element = $(".full-screen");
        var $minheight = $window.height();
        element.css('min-height', $minheight);
    }

    // 06. ScreenFixedHeight function
    function ScreenFixedHeight() {
      
        var element = $(".screen-height");
        var $screenheight = $window.height();
        element.css('height', $screenheight);
    }

      function SetResizeContent() {
        fullScreenHeight();
        ScreenFixedHeight();
    }

       SetResizeContent();

// MMenu Init
if($(window).width() <= 1023){
	$("#menu").mmenu({
		"offCanvas": {
			"position": "right"
		}
	});

}

 // Header Fixed   
 $(window).scroll(function () {
 	var height = $(window).scrollTop();
 	if (height >100) {
 		$('header').addClass('header-fixed');
 	}
 	else if (height == 0) {
 		$('header').removeClass('header-fixed');
 	}
 }); 
})(jQuery);